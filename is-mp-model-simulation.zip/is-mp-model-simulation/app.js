
(function(){
  'use strict';
  const $ = id => document.getElementById(id);
  const root = document.documentElement;

  /* =============== Tema y presentación =============== */
  const theme = $('theme');
  const applyTheme = () => root.classList.toggle('light', !theme.checked);
  theme.addEventListener('change', applyTheme, {passive:true});
  applyTheme();
  $('togglePresent').addEventListener('click', ()=> document.body.classList.toggle('present'));

  /* =============== DOM refs =============== */
  const els = {
    a:$('a'), da:$('da'), b:$('b'), ip:$('ip'), r:$('r'), xc:$('xc'),
    ymin:$('ymin'), ymax:$('ymax'), imin:$('imin'), imax:$('imax'),
    aVal:$('aVal'), daVal:$('daVal'), bVal:$('bVal'), ipVal:$('ipVal'), rVal:$('rVal'), xcVal:$('xcVal'),
    svg:$('chart'), eqn:$('eqn'), stats:$('stats'), theoryAuto:$('theoryAuto'),
    err:$('err'), warn:$('warn'),
    regChip:$('regChip'), polChip:$('polChip'), shockChip:$('shockChip'),
    dotReg:$('dotReg'), dotPol:$('dotPol'), dotShock:$('dotShock'),
    reset:$('reset'), save:$('save'), load:$('load'), autofit:$('autofit'), exportBtn:$('export'),
    tabs:$('tabs'),
    presetList:$('presetList'), applyPreset:$('applyPreset'),
    presetName:$('presetName'), savePreset:$('savePreset'),
    renamePreset:$('renamePreset'), deletePreset:$('deletePreset'), resetPresets:$('resetPresets')
  };

  /* =============== Estado del modelo =============== */
  const st = {a:0, da:0, b:2, ip:2, r:0, xc:0, ymin:-10, ymax:15, imin:-10, imax:15};

  /* =============== SVG setup =============== */
  function mk(tag, attrs={}){ const e=document.createElementNS('http://www.w3.org/2000/svg',tag); for(const k in attrs) e.setAttribute(k,attrs[k]); return e; }
  const W=900,H=560,M={l:68,t:36,r:28,b:54}, IW=W-M.l-M.r, IH=H-M.t-M.b;
  const g=mk('g',{transform:`translate(${M.l},${M.t})`}); els.svg.appendChild(g);
  const gridG=mk('g',{class:'grid'}), axX=mk('g',{class:'axis x'}), axY=mk('g',{class:'axis y'}), cur=mk('g'), help=mk('g');
  g.append(gridG,axX,axY,cur,help);
  const pathIS=mk('path',{class:'is'}), pathMP=mk('path',{class:'mp'}), dot=mk('circle',{class:'eq',r:6});
  const dY=mk('line',{class:'dash'}), dI=mk('line',{class:'dash'}), labY=mk('text',{class:'label'}), labI=mk('text',{class:'label'});
  cur.append(pathIS,pathMP); help.append(dot,dY,dI,labY,labI);
  const tagIS=mk('text',{class:'label'}), tagMP=mk('text',{class:'label'}); help.append(tagIS,tagMP);

  /* =============== Escalas =============== */
  let xS,yS,xInv,yInv;
  const lin=(d0,d1,r0,r1)=>{ const m=(r1-r0)/(d1-d0); return x=> r0 + (x-d0)*m; };
  function updScales(){ xS=lin(st.ymin,st.ymax,0,IW); yS=lin(st.imax,st.imin,0,IH); xInv=lin(0,IW,st.ymin,st.ymax); yInv=lin(0,IH,st.imax,st.imin); }

  /* =============== Modelo =============== */
  function i_of_Y(Y){ return st.r + ((st.a+st.da) - (1-st.xc)*Y)/st.b; }
  function Y_of_i(i){ return ((st.a+st.da) - st.b*(i-st.r)) / Math.max(1-st.xc, 1e-6); }

  /* =============== Helpers UI =============== */
  const fmt = x => Number.isFinite(x) ? (+x).toFixed(2) : '—';
  function setVals(){ els.aVal.textContent=fmt(st.a); els.daVal.textContent=fmt(st.da); els.bVal.textContent=fmt(st.b); els.ipVal.textContent=fmt(st.ip); els.rVal.textContent=fmt(st.r); els.xcVal.textContent=fmt(st.xc); }

  // Edición inline de números (clic sobre el valor al lado de cada slider)
  function clampToStep(val, step){ const s=+step||0.01; return Math.round(val/s)*s; }
  function enableInlineEdit(spanEl, rangeEl){
    spanEl.classList.add('value-span'); spanEl.title='Haz clic para editar';
    spanEl.addEventListener('click', ()=>{
      if(spanEl.classList.contains('editing')) return;
      spanEl.classList.add('editing');
      const min = parseFloat(rangeEl.min ?? -Infinity);
      const max = parseFloat(rangeEl.max ??  Infinity);
      const step = parseFloat(rangeEl.step || '0.01');
      const input = document.createElement('input');
      input.type='number'; input.className='val-input'; input.step=step;
      if(Number.isFinite(min)) input.min=String(min);
      if(Number.isFinite(max)) input.max=String(max);
      input.value=String(rangeEl.value);
      spanEl.textContent=''; spanEl.appendChild(input); input.focus(); input.select();
      const commit=(apply=true)=>{
        if(apply){
          let v=parseFloat(input.value); if(isNaN(v)) v=+rangeEl.value;
          if(Number.isFinite(min)) v=Math.max(min,v);
          if(Number.isFinite(max)) v=Math.min(max,v);
          v=clampToStep(v,step);
          rangeEl.value=String(v);
          rangeEl.dispatchEvent(new Event('input',{bubbles:true}));
          rangeEl.dispatchEvent(new Event('change',{bubbles:true}));
          spanEl.textContent=fmt(+rangeEl.value);
        }else spanEl.textContent=fmt(+rangeEl.value);
        spanEl.classList.remove('editing');
      };
      input.addEventListener('keydown',e=>{ if(e.key==='Enter') commit(true); if(e.key==='Escape') commit(false); });
      input.addEventListener('blur',()=>commit(true));
    });
  }
  enableInlineEdit(els.aVal,els.a); enableInlineEdit(els.daVal,els.da);
  enableInlineEdit(els.bVal,els.b); enableInlineEdit(els.ipVal,els.ip);
  enableInlineEdit(els.rVal,els.r); enableInlineEdit(els.xcVal,els.xc);

  /* =============== Ejes (solo si cambian rangos) =============== */
  let lastRanges=null;
  function drawAxes(force=false){
    const sig=`${st.ymin},${st.ymax},${st.imin},${st.imax}`;
    if(!force && sig===lastRanges) return;
    lastRanges=sig;
    gridG.innerHTML=''; axX.innerHTML=''; axY.innerHTML='';
    for(let i=0;i<=10;i++){ const y=IH*i/10; gridG.appendChild(mk('line',{x1:0,y1:y,x2:IW,y2:y})); }
    for(let j=0;j<=10;j++){ const x=IW*j/10; gridG.appendChild(mk('line',{x1:x,y1:0,x2:x,y2:IH})); }
    axX.appendChild(mk('line',{x1:0,y1:IH,x2:IW,y2:IH}));
    const tx=8;
    for(let t=0;t<=tx;t++){ const xv=st.ymin+(st.ymax-st.ymin)*t/tx, x=xS(xv);
      axX.appendChild(mk('line',{x1:x,y1:IH,x2:x,y2:IH+6}));
      const tt=mk('text',{x:x,y:IH+18,'text-anchor':'middle'}); tt.textContent=xv.toFixed(1); axX.appendChild(tt);
    }
    axY.appendChild(mk('line',{x1:0,y1:0,x2:0,y2:IH}));
    const ty=8;
    for(let t=0;t<=ty;t++){ const iv=st.imin+(st.imax-st.imin)*t/ty, y=yS(iv);
      axY.appendChild(mk('line',{x1:-6,y1:y,x2:0,y2:y}));
      const tt=mk('text',{x:-10,y:y+4,'text-anchor':'end'}); tt.textContent=iv.toFixed(1); axY.appendChild(tt);
    }
    const xlab=mk('text',{x:IW/2,y:H-M.b/3,'text-anchor':'middle'}); xlab.textContent='Y~ (brecha de producto)'; axX.appendChild(xlab);
    const ylab=mk('text',{x:-44,y:IH/2,transform:`rotate(-90 -44 ${IH/2})`,'text-anchor':'middle'}); ylab.textContent='i (tasa de interés real)'; axY.appendChild(ylab);
  }

  /* =============== Guardrails =============== */
  function guardrails(){
    const notes=[];
    if(!(isFinite(st.b)) || st.b<=0){ st.b=0.1; els.b.value=st.b; notes.push('b→0.1 para pendiente negativa.'); }
    if(st.xc>=0.9){ st.xc=0.85; els.xc.value=st.xc; notes.push('x_c ≤ 0.85 para multiplicador finito.'); }
    if(st.ymax<=st.ymin){ st.ymin=-10; st.ymax=15; els.ymin.value=st.ymin; els.ymax.value=st.ymax; notes.push('Rango Y~ restablecido.'); }
    if(st.imax<=st.imin){ st.imin=-10; st.imax=15; els.imin.value=st.imin; els.imax.value=st.imax; notes.push('Rango i restablecido.'); }
    const Ystar = Y_of_i(st.ip);
    let suggest = '';
    if(isFinite(Ystar) && (Ystar<st.ymin || Ystar>st.ymax || st.ip<st.imin || st.ip>st.imax)) suggest='Equilibrio fuera de vista: usa Auto-fit.';
    els.warn.textContent = suggest || (notes.length?notes.join(' '):'');
    els.warn.classList.toggle('show', !!suggest || notes.length>0);
  }
  function validate(){
    const errs=[];
    if(st.b<=0) errs.push('b debe ser > 0');
    if(st.xc>=1) errs.push('x_c < 1 para multiplicador finito');
    els.err.textContent=errs.join(' · ');
    els.err.classList.toggle('show', errs.length>0);
    return errs.length===0;
  }

  /* =============== Ecuaciones (MathML) – SOLO una versión =============== */
  function equationsMathML(){
    const baseNumerator = `
      <mrow>
        <mo>(</mo><mi>a</mi><mo>+</mo><mi>Δa</mi><mo>)</mo>
        <mo>−</mo>
        <mi>b</mi><mo>(</mo><mi>i</mi><mo>−</mo><mi>r</mi><mo>)</mo>
      </mrow>`;
    const hasXC = st.xc > 0;
    const Yline = hasXC
      ? `<math display="block">
           <mover accent="true"><mi>Ŷ</mi><mo>~</mo></mover>
           <mo>=</mo>
           <mfrac>
             ${baseNumerator}
             <mrow><mn>1</mn><mo>−</mo><msub><mi>x</mi><mi>c</mi></msub></mrow>
           </mfrac>
         </math>`
      : `<math display="block">
           <mover accent="true"><mi>Ŷ</mi><mo>~</mo></mover>
           <mo>=</mo>
           ${baseNumerator}
         </math>`;
    return `
      <div class="math-block">
        ${Yline}
        <math display="block"><mi>i</mi><mo>=</mo><msub><mi>i</mi><mtext>policy</mtext></msub></math>
      </div>`;
  }

  /* =============== Render con rAF =============== */
  let pending=false;
  function scheduleRender(){ if(!pending){ pending=true; requestAnimationFrame(renderFrame); } }

  function renderFrame(){
    pending=false;
    try{
      setVals(); guardrails(); updScales(); drawAxes(); if(!validate()) return;

      // IS
      const N = Math.max(160, Math.min(360, Math.round(IW/3)));
      const seg = [];
      for(let k=0;k<=N;k++){
        const Y = st.ymin + (st.ymax-st.ymin)*k/N;
        const i = i_of_Y(Y);
        seg.push((k?'L':'M') + xS(Y) + ',' + yS(i));
      }
      pathIS.setAttribute('d', seg.join(' '));

      // MP
      const ymp = yS(st.ip);
      pathMP.setAttribute('d','M0,'+ymp+' L'+IW+','+ymp);

      // Equilibrio
      const Ystar = Y_of_i(st.ip), xs=xS(Ystar), ys=yS(st.ip);
      if(isFinite(Ystar) && Math.abs(Ystar) < 1e6){
        dot.setAttribute('cx',xs); dot.setAttribute('cy',ys);
        dY.setAttribute('x1',xs); dY.setAttribute('x2',xs); dY.setAttribute('y1',ys); dY.setAttribute('y2',yS(st.imin));
        dI.setAttribute('x1',xs); dI.setAttribute('x2',0);  dI.setAttribute('y1',ys); dI.setAttribute('y2',ys);
        labY.setAttribute('x',xs+6); labY.setAttribute('y',yS(st.imin)-6); labY.textContent='Y* = '+fmt(Ystar);
        labI.setAttribute('x',6);    labI.setAttribute('y',ys-6);           labI.textContent='i* = '+fmt(st.ip);
      }

      // Etiquetas IS/MP en el gráfico
      tagIS.setAttribute('x', IW-10); tagIS.setAttribute('y', yS(i_of_Y(xInv(IW-10))) - 6);
      tagIS.setAttribute('text-anchor','end'); tagIS.textContent='IS';
      tagMP.setAttribute('x', IW-10); tagMP.setAttribute('y', yS(st.ip) - 6);
      tagMP.setAttribute('text-anchor','end'); tagMP.textContent='MP';

      // Ecuaciones (una sola representación coherente)
      els.eqn.innerHTML = equationsMathML();

      // Stats y chips
      const slope = -1/st.b, mult = 1/(1-st.xc);
      const metric = (t,v,cls='')=>`<div class="stat"><div class="t">${t}</div><div class="v ${cls}">${v}</div></div>`;
      els.stats.innerHTML = [
        metric('a, Δa, r', `a=${fmt(st.a)} · Δa=${fmt(st.da)} · r=${fmt(st.r)}`),
        metric('b (pend. IS)', `b=${fmt(st.b)} · pend=${fmt(slope)}`),
        metric('i_policy', `${fmt(st.ip)}`),
        metric('x_c (mult.)', `${fmt(st.xc)} · ${mult.toFixed(2)}`),
        metric('Equilibrio Y*', fmt(Ystar), (Ystar>=0?'good':'bad')),
        metric('Equilibrio i*', fmt(st.ip), 'info')
      ].join('');

      els.regChip.textContent = Ystar>0?'Expansión':(Ystar<0?'Recesión':'Potencial');
      els.polChip.textContent = st.ip>st.r?'MP contractiva':(st.ip<st.r?'MP expansiva':'MP neutral');
      els.shockChip.textContent = st.da>0?'Shock demanda (+)':(st.da<0?'Shock demanda (−)':'Sin shock demanda');
      els.dotReg.style.background = Ystar>=0?'#10b981':'#ef4444';
      els.dotPol.style.background = st.ip>st.r?'#ef4444':(st.ip<st.r?'#10b981':'#f59e0b');
      els.dotShock.style.background = st.da===0?'#6b7280':(st.da>0?'#10b981':'#ef4444');

      els.theoryAuto.innerHTML =
        `<strong>Interpretación:</strong> ${st.da>0?'Δa>0 ⇒ IS →. ':''}${st.da<0?'Δa<0 ⇒ IS ←. ':''}`
        + `${st.ip>st.r?'MP contractiva (i_policy>r) comprime Y~. ':''}${st.ip<st.r?'MP expansiva (i_policy<r) impulsa Y~. ':''}`
        + `Pendiente IS=${fmt(slope)} (b=${fmt(st.b)}); multiplicador=${mult.toFixed(2)}.`;

      els.err.classList.remove('show');
    }catch(e){
      els.err.textContent = 'Error de render: ' + (e && e.message ? e.message : e);
      els.err.classList.add('show');
      console.error(e);
    }
  }

  /* =============== Teoría (tabs) =============== */
  const THEORY = [
    { t:'Curva IS', x:`La IS muestra relación negativa entre i e Y~: i↑ ⇒ I↓ ⇒ Y↓. Su pendiente es −1/b.` },
    { t:'Choques de demanda', x:`Δa>0 traslada IS → (expansión autónoma). Δa<0 traslada IS ← (contracción).` },
    { t:'Canal de inversión', x:`El canal dominante en el corto plazo: sensibilidad b. b alto ⇒ IS plana ⇒ Y~ responde más a i.` },
    {
      t:'Regla MP',
      html: `
        <div>La autoridad fija la tasa de política como línea horizontal:</div>
        <div class="math-block">
          <math display="block"><mi>i</mi><mo>=</mo><msub><mi>i</mi><mtext>policy</mtext></msub></math>
          <math display="block"><msub><mi>i</mi><mtext>policy</mtext></msub><mo>&gt;</mo><mi>r</mi><mo>⇒</mo><mtext>contractiva</mtext></math>
          <math display="block"><msub><mi>i</mi><mtext>policy</mtext></msub><mo>&lt;</mo><mi>r</mi><mo>⇒</mo><mtext>expansiva</mtext></math>
        </div>
        <div class="muted">El cruce con IS determina (Y*, i*).</div>
      `
    },
    { t:'Contabilidad', x:`Y=C+I+G+NX. En corto plazo, IS resume cómo i afecta la DA vía I (y algo C).` }
  ];
  (function buildTabs(){
    const tabs=els.tabs;
    tabs.innerHTML='';
    THEORY.forEach((obj,i)=>{
      const b=document.createElement('button');
      b.className='tab'+(i===0?' active':'');
      b.textContent=obj.t;
      b.onclick=()=>{
        document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
        b.classList.add('active');
        const box=$('theory');
        if(obj.html){ box.innerHTML=obj.html; } else { box.textContent=obj.x; }
      };
      tabs.appendChild(b);
    });
    $('theory').textContent = THEORY[0].x;
  })();

  /* =============== Sync (ligero y con rangos) =============== */
  function syncLight(){
    st.a=+els.a.value; st.da=+els.da.value; st.b=Math.max(0.0001,+els.b.value);
    st.ip=+els.ip.value; st.r=+els.r.value; st.xc=+els.xc.value;
    scheduleRender();
  }
  function syncRanges(){
    st.ymin=+els.ymin.value; st.ymax=+els.ymax.value; st.imin=+els.imin.value; st.imax=+els.imax.value;
    lastRanges=null; scheduleRender();
  }
  ['a','da','b','ip','r','xc'].forEach(id=>{ $(id).addEventListener('input',syncLight,{passive:true}); $(id).addEventListener('change',syncLight); });
  ['ymin','ymax','imin','imax'].forEach(id=>{ $(id).addEventListener('input',syncRanges); $(id).addEventListener('change',syncRanges); });

  // Accesibilidad de sliders (teclado)
  function keyStep(el, step=+el.step||0.1){
    el.addEventListener('keydown', e=>{
      if(e.key==='ArrowLeft'){ el.value=(+el.value - step).toFixed(2); el.dispatchEvent(new Event('input')); e.preventDefault(); }
      if(e.key==='ArrowRight'){ el.value=(+el.value + step).toFixed(2); el.dispatchEvent(new Event('input')); e.preventDefault(); }
    });
  }
  ['a','da','b','ip','r','xc'].forEach(id=>keyStep($(id)));

  /* =============== Botones varios =============== */
  $('reset').addEventListener('click', ()=>{
    Object.assign(st,{a:0,da:0,b:2,ip:2,r:0,xc:0,ymin:-10,ymax:15,imin:-10,imax:15});
    els.a.value=0; els.da.value=0; els.b.value=2; els.ip.value=2; els.r.value=0; els.xc.value=0;
    els.ymin.value=-10; els.ymax.value=15; els.imin.value=-10; els.imax.value=15;
    lastRanges=null; scheduleRender();
  });
  $('autofit').addEventListener('click',()=>{
    const Ys = Y_of_i(st.ip);
    const spanY=10, spanI=Math.max(6, Math.abs(st.ip-st.r)*2+4);
    st.ymin=Math.floor(Ys-spanY); st.ymax=Math.ceil(Ys+spanY);
    st.imin=Math.floor(st.ip-spanI); st.imax=Math.ceil(st.ip+spanI);
    els.ymin.value=st.ymin; els.ymax.value=st.ymax; els.imin.value=st.imin; els.imax.value=st.imax;
    lastRanges=null; scheduleRender();
  });

  // Export PNG
  $('export').addEventListener('click',()=>{
    try{
      const s=new XMLSerializer().serializeToString(els.svg);
      const blob=new Blob([s],{type:'image/svg+xml;charset=utf-8'});
      const url=URL.createObjectURL(blob);
      const img=new Image();
      img.onload=function(){
        const c=document.createElement('canvas'); c.width=900; c.height=560;
        const ctx=c.getContext('2d');
        ctx.fillStyle=getComputedStyle(document.documentElement).getPropertyValue('--bg').trim()||'#fff';
        ctx.fillRect(0,0,c.width,c.height); ctx.drawImage(img,0,0); URL.revokeObjectURL(url);
        c.toBlob((b)=>{ const a=document.createElement('a'); a.href=URL.createObjectURL(b); a.download='IS_MP.png'; a.click(); },'image/png');
      };
      img.src=url;
    }catch(e){ alert('Error al exportar.'); }
  });

  /* =============== Splitters =============== */
  const ws=$('ws'); let dragging=null;
  ws.addEventListener('pointerdown',(e)=>{
    const s=e.target.closest('.splitter'); if(!s) return; e.preventDefault();
    const cs=getComputedStyle(root);
    dragging={side:s.dataset.split,startX:e.clientX,l:parseFloat(cs.getPropertyValue('--col-left'))||26,c:parseFloat(cs.getPropertyValue('--col-center'))||48,r:parseFloat(cs.getPropertyValue('--col-right'))||26};
    s.setPointerCapture(e.pointerId);
  });
  ws.addEventListener('pointermove',(e)=>{
    if(!dragging) return;
    const dx=e.clientX-dragging.startX, Wpx=ws.clientWidth, dFrac=(dx/Math.max(Wpx,1))*100;
    let {l,c,r}=dragging;
    if(dragging.side==='left-center'){ l=Math.max(15,l+dFrac); c=Math.max(25,c-dFrac); }
    if(dragging.side==='center-right'){ c=Math.max(25,c+dFrac); r=Math.max(15,r-dFrac); }
    const sum=l+c+r, scale=(dragging.l+dragging.c+dragging.r)/sum; l*=scale; c*=scale; r*=scale;
    root.style.setProperty('--col-left',l); root.style.setProperty('--col-center',c); root.style.setProperty('--col-right',r);
  });
  ws.addEventListener('pointerup',()=>{ dragging=null; });
  ws.addEventListener('pointercancel',()=>{ dragging=null; });

  /* =============== PRESETS (sessionStorage) =============== */
  const SS_KEY='ISMP_SESSION_PRESETS_V1';
  const defaultPresets = [
    {name:'Base neutral', p:{a:0,da:0,b:2,ip:2,r:2,xc:0.15,ymin:-10,ymax:15,imin:-2,imax:8}},
    {name:'Recesión (shock −Δa)', p:{a:0,da:-2.5,b:2.2,ip:1.5,r:1.5,xc:0.25,ymin:-12,ymax:10,imin:-2,imax:8}},
    {name:'Expansión (shock +Δa)', p:{a:0,da:2.5,b:2.2,ip:0.5,r:1,xc:0.25,ymin:-5,ymax:15,imin:-2,imax:6}},
    {name:'MP Contractiva', p:{a:0,da:0.2,b:2,ip:4.0,r:1.5,xc:0.2,ymin:-12,ymax:8,imin:0,imax:8}},
    {name:'MP Expansiva', p:{a:0,da:0,b:2.2,ip:-1.0,r:1.0,xc:0.2,ymin:-6,ymax:14,imin:-4,imax:4}}
  ];
  function loadPresets(){
    const raw=sessionStorage.getItem(SS_KEY); let arr;
    try{ arr=raw?JSON.parse(raw):null; }catch(_){ arr=null; }
    if(!arr||!Array.isArray(arr)||arr.length===0){
      arr=JSON.parse(JSON.stringify(defaultPresets));
      sessionStorage.setItem(SS_KEY, JSON.stringify(arr));
    }
    return arr;
  }
  function savePresets(arr){ sessionStorage.setItem(SS_KEY, JSON.stringify(arr)); }
  function refreshPresetList(){
    const arr=loadPresets(); els.presetList.innerHTML='';
    arr.forEach((it,i)=>{ const o=document.createElement('option'); o.value=i; o.textContent=it.name; els.presetList.appendChild(o); });
  }
  function applyPresetByIndex(idx){
    const arr=loadPresets(); const it=arr[idx|0]; if(!it) return;
    Object.assign(st, it.p);
    // Sincroniza UI
    els.a.value=st.a; els.da.value=st.da; els.b.value=st.b; els.ip.value=st.ip; els.r.value=st.r; els.xc.value=st.xc;
    els.ymin.value=st.ymin; els.ymax.value=st.ymax; els.imin.value=st.imin; els.imax.value=st.imax;
    lastRanges=null; scheduleRender();
    // Teoría contextual
    const desc = describePreset(it);
    $('theory').textContent = desc.title;
    els.theoryAuto.innerHTML = `<strong>Explicación (preset):</strong> ${desc.text}`;
    document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
    els.tabs.children[1]?.classList.add('active');
  }
  function describePreset(it){
    const p=it.p;
    const Ystar=((p.a+p.da)-p.b*(p.ip-p.r))/Math.max(1-p.xc,1e-6);
    const stance=p.ip>p.r?'contractiva':(p.ip<p.r?'expansiva':'neutral');
    let text=`Con i_policy ${p.ip.toFixed(2)} y r ${p.r.toFixed(2)}, la postura MP es ${stance}. `;
    if(p.da>0) text+='Δa>0 desplaza IS → (expansión autónoma). ';
    if(p.da<0) text+='Δa<0 desplaza IS ← (contracción autónoma). ';
    text+=`Equilibrio aprox. Y*=${Ystar.toFixed(2)}; multiplicador ${(1/(1-p.xc)).toFixed(2)}.`;
    return {title:it.name, text};
  }
  refreshPresetList();
  els.applyPreset.addEventListener('click',()=>applyPresetByIndex(els.presetList.value));
  els.savePreset.addEventListener('click',()=>{
    const name = els.presetName.value.trim() || `Mi preset ${Date.now()%10000}`;
    const arr=loadPresets(); arr.push({name, p:{...st}}); savePresets(arr); refreshPresetList(); els.presetName.value='';
  });
  els.renamePreset.addEventListener('click',()=>{
    const idx=+els.presetList.value; const arr=loadPresets(); if(!arr[idx]) return;
    const name = els.presetName.value.trim(); if(!name) return alert('Escribe el nuevo nombre.');
    arr[idx].name=name; savePresets(arr); refreshPresetList(); els.presetName.value='';
  });
  els.deletePreset.addEventListener('click',()=>{
    const idx=+els.presetList.value; const arr=loadPresets(); if(!arr[idx]) return;
    arr.splice(idx,1); savePresets(arr); refreshPresetList();
  });
  els.resetPresets.addEventListener('click',()=>{
    savePresets(JSON.parse(JSON.stringify(defaultPresets))); refreshPresetList();
  });

  /* =============== Persistencia efímera =============== */
  const KEY='ISMP_STATE_EPHEMERAL';
  $('save').addEventListener('click',()=>{ try{ sessionStorage.setItem(KEY, JSON.stringify(st)); alert('Guardado en esta sesión.'); }catch(_){ alert('No se pudo guardar.'); }});
  $('load').addEventListener('click',()=>{ try{
    const x=JSON.parse(sessionStorage.getItem(KEY)||'null'); if(!x) return;
    Object.assign(st,x);
    els.a.value=st.a; els.da.value=st.da; els.b.value=st.b; els.ip.value=st.ip; els.r.value=st.r; els.xc.value=st.xc;
    els.ymin.value=st.ymin; els.ymax.value=st.ymax; els.imin.value=st.imin; els.imax.value=st.imax; lastRanges=null; scheduleRender();
  }catch(_){ alert('No se pudo cargar.'); }});

  /* =============== Primer render =============== */
  lastRanges=null; scheduleRender();
})();
